import os
GAME_URL = 'file://' + os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'game', 'index.html'))
import sys, json
from playwright.sync_api import sync_playwright
def test(cases, shots=True):
    out=[]
    with sync_playwright() as p:
        b=p.chromium.launch()
        pg=b.new_page(viewport={'width':390,'height':780})
        errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(GAME_URL); pg.wait_for_timeout(300)
        for (lv, pts) in cases:
            pg.evaluate(f'MJ.startLevel({lv})'); pg.wait_for_timeout(150)
            v=pg.evaluate('({s:MJ.view.s,ox:MJ.view.ox,oy:MJ.view.oy})')
            sc=lambda q:(v['ox']+q[0]*v['s'], v['oy']+q[1]*v['s'])
            # densify
            dense=[]
            for i in range(len(pts)-1):
                a,c=pts[i],pts[i+1]
                for k in range(12): dense.append((a[0]+(c[0]-a[0])*k/12, a[1]+(c[1]-a[1])*k/12))
            dense.append(pts[-1])
            x,y=sc(dense[0]); pg.mouse.move(x,y); pg.mouse.down()
            for q in dense[1:]:
                x,y=sc(q); pg.mouse.move(x,y)
            pg.mouse.up()
            snap=None
            for i in range(60):
                pg.wait_for_timeout(250)
                st=pg.evaluate('MJ.state')
                if i==10 and shots: pg.screenshot(path=f'run{lv}.png')
                if st in ('win','fail'): break
            f=pg.evaluate('MJ.fill')
            if shots: pg.screenshot(path=f'end{lv}.png')
            out.append((lv, st, f))
        print(out, 'ERR', errs[:3])
        b.close()
if __name__=='__main__':
    cases=json.loads(sys.argv[1]); test(cases)
