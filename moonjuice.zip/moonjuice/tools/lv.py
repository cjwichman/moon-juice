import sys,json
from sim import *
def run(n, L, strokes, seeds=(1,2,3), nodraw=True):
    with sync_playwright() as p:
        b,pg,e=page(p)
        pg.evaluate(f'Object.assign(MJ.HAND[{n-1}], {json.dumps(L)})')
        if nodraw:
            print(' nodraw', [ (o['st'],o['fill']) for o in [pg.evaluate(f'MJ.simStroke({n},[[14,90],[26,90]],{s})') for s in (1,2)]])
        for sk in strokes:
            r=[pg.evaluate(f'MJ.simStroke({n},{json.dumps(sk)},{s})') for s in seeds]
            print(' ',sk, [(o['st'],o['fill'],o['ink']) if o else 'INVALID' for o in r], flush=True)
        if e: print(e)
