import sys,json
from sim import *
from sols import blob
def thru(p,q,x0,x1):
    k=(q[1]-p[1])/(q[0]-p[0]); f=lambda x:round(p[1]+k*(x-p[0]))
    return [[x0,f(x0)],[x1,f(x1)]]
def go(cases):
    with sync_playwright() as p:
        b,pg,e=page(p)
        for n,L,strokes in cases:
            if L: pg.evaluate(f'Object.assign(MJ.HAND[{n-1}], {json.dumps(L)})')
            nd=[pg.evaluate(f'MJ.simStroke({n},[[14,90],[26,90]],{s})') for s in (1,2)]
            print(n,'nodraw',[(o['st'],o['fill']) for o in nd])
            for sk in strokes:
                r=[pg.evaluate(f'MJ.simStroke({n},{json.dumps(sk)},{s})') for s in (1,2,3)]
                print('  ',json.dumps(sk), [(o['st'],o['fill'][0],o['ink']) if o else 'INVALID' for o in r], flush=True)
        if e: print(e)
