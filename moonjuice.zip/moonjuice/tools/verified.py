# Verified reference strokes (world coords, 400x700) for levels that pass 3/3 seeds
# under the current physics. Run: python3 verified.py
import json
from sim import *
from sols import blob
ice2={'x':200,'y':470,'w':340,'h':26,'a':16}
ice15={'x':180,'y':420,'w':330,'h':26,'a':20}
V={
 1:[[50,306],[258,488]],
 2:blob(ice2,190,up=10,w=30,h=24),
 4:[[360,325],[125,507]],
 15:blob(ice15,230,up=10,w=30,h=24),
}
if __name__=='__main__':
    with sync_playwright() as p:
        b,pg,e=page(p)
        for n,sk in V.items():
            r=[pg.evaluate(f'MJ.simStroke({n},{json.dumps(sk)},{s})') for s in (1,2,3)]
            nd=pg.evaluate(f'MJ.simStroke({n},[[14,90],[26,90]],1)')
            print(n,'nodraw',nd['st'],'| sol',[(o['st'],o['fill']) if o else 'INVALID' for o in r])
        b.close()
