import math
def surf(p,x):
    a=math.radians(p['a']); along=(x-p['x'])/math.cos(a)
    return (p['x']+along*math.cos(a)+p['h']/2*math.sin(a), p['y']+along*math.sin(a)-p['h']/2*math.cos(a))
def blob(p,x,up=6,w=18,h=18):
    # small closed triangle sitting just above slab p near x
    l=surf(p,x-w/2); r=surf(p,x+w/2)
    return [[l[0],l[1]-up],[r[0],r[1]-up],[x+2,min(l[1],r[1])-up-h],[l[0]+2,l[1]-up-1]]
def S(L):
    P=lambda i:L[i]
    return None
