import re,sys
s=open('src.html').read()
cupd,lined,fs=sys.argv[1:4]
i=s.index('function buildCup'); j=s.index('const opt = { density:',i); k=s.index('};',j)
s=s[:j]+f'const opt = {{ density: {cupd} '+s[k:]
i=s.index('function commitStroke'); j=s.index('const opt = { density:',i); k=s.index('};',j)
s=s[:j]+f'const opt = {{ density: {lined} '+s[k:]
s=re.sub(r"if \(o === 'rock' \|\| o === 'ice' \|\| o === 'peg'\) \{ pair.friction = 1; pair.frictionStatic = [0-9.]+; \}", f"if (o === 'rock' || o === 'ice' || o === 'peg') {{ pair.friction = 1; pair.frictionStatic = {fs}; }}", s)
open('src.html','w').write(s)
