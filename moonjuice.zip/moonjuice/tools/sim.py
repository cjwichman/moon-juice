import os
GAME_URL = 'file://' + os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'game', 'index.html'))
import sys, json
from playwright.sync_api import sync_playwright
def page(p):
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':390,'height':780})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(GAME_URL); pg.wait_for_timeout(300); return b,pg,errs
if __name__=='__main__':
    mode=sys.argv[1]
    with sync_playwright() as p:
        b,pg,errs=page(p)
        if mode=='sols':
            from run_all import S
        if mode=='nodraw':
            for n in range(1,16):
                print(n, [pg.evaluate(f'MJ.simStroke({n},[[14,90],[26,90]],{s})') for s in (1,2)])
        if mode=='search':
            for n in [int(x) for x in sys.argv[3:]]:
                print(n, pg.evaluate(f'MJ.searchLevel({n},{int(sys.argv[2])})'), flush=True)
        print('ERR',errs[:3]); b.close()
def sols(pg, which=None):
    from run_all import S
    for n in (which or range(1,16)):
        r=[pg.evaluate(f'MJ.simStroke({n},{json.dumps(S[n])},{s})') for s in (1,2,3)]
        print(n, [ (o["st"],o["fill"]) if o else 'INVALID' for o in r], flush=True)
if __name__=='__main__' and sys.argv[1]=='sols2':
    with sync_playwright() as p:
        b,pg,errs=page(p); sols(pg); print(errs[:3]); b.close()
