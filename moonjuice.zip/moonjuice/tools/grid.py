import sys
from sim import *
from PIL import Image
lvls=[int(x) for x in sys.argv[1:]]
with sync_playwright() as p:
    b,pg,e=page(p); ims=[]
    for n in lvls:
        pg.evaluate(f'MJ.startLevel({n})'); pg.wait_for_timeout(200); pg.evaluate("document.querySelectorAll('.toast,#toast').forEach(t=>t.style.display='none')")
        pg.screenshot(path='_g.png'); ims.append(Image.open('_g.png').resize((240,480)))
    c=Image.new('RGB',(240*len(ims),480))
    for i,im in enumerate(ims): c.paste(im,(240*i,0))
    c.save('/tmp/grid.png'); b.close()
