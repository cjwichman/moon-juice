import os
GAME_URL = 'file://' + os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'game', 'index.html'))
import sys, json
from playwright.sync_api import sync_playwright
from PIL import Image
sys.argv=sys.argv
import run_all_sols as RS
def seq(lv, pts, times=(300,900,1800,3500), name=None):
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(viewport={'width':390,'height':780})
        pg.goto(GAME_URL); pg.wait_for_timeout(300)
        pg.evaluate(f'MJ.startLevel({lv})'); pg.wait_for_timeout(100)
        v=pg.evaluate('({s:MJ.view.s,ox:MJ.view.ox,oy:MJ.view.oy})')
        sc=lambda q:(v['ox']+q[0]*v['s'], v['oy']+q[1]*v['s'])
        dense=[]
        for i in range(len(pts)-1):
            a,c=pts[i],pts[i+1]
            for k in range(12): dense.append((a[0]+(c[0]-a[0])*k/12, a[1]+(c[1]-a[1])*k/12))
        dense.append(pts[-1])
        pg.mouse.move(*sc(dense[0])); pg.mouse.down()
        for q in dense[1:]: pg.mouse.move(*sc(q))
        pg.screenshot(path='_pre.png')
        pg.mouse.up()
        imgs=[Image.open('_pre.png').resize((260,520))]
        t0=0
        for t in times:
            pg.wait_for_timeout(t-t0); t0=t
            pg.screenshot(path='_f.png'); imgs.append(Image.open('_f.png').resize((260,520)))
        print(lv, pg.evaluate('MJ.state'), pg.evaluate('MJ.fill'))
        c=Image.new('RGB',(260*len(imgs),520))
        for k,i in enumerate(imgs): c.paste(i,(260*k,0))
        c.save(name or f'seq{lv}.png')
        b.close()
if __name__=='__main__':
    lv=int(sys.argv[1]); seq(lv, RS.S[lv])
