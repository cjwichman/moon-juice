# Moon Juice — status (2026-10-03)

Happy Glass–style game in the retro-space suite. One stroke per level. The stroke becomes a physics body and falls with gravity. Liquid pours from one or two saucer nozzles. The level clears when the cup holds liquid above the fill line for 0.9 s.

## Layout

- `game/src.html` — game source. Contains a `/*__MATTER__*/` placeholder.
- `game/build.py` — inlines `vendor/matter.min.js` and writes `game/index.html`.
- `game/index.html` — built single file. Not shippable yet (see level status).
- `vendor/` — matter-js 0.19.0 (MIT), minified and full builds.
- `tools/` — Playwright harness that drives the real game through test hooks.
- `prototype/` — earlier standalone Node physics core and level drafts. Kept for reference. Its findings are folded into `game/src.html`.
- `screens/` — title screen and early level screenshots.

Requirements for the tools: Python 3, `playwright` (Chromium installed), Pillow. The prototype needs Node.

## What works

- Title screen, level grid with stars, HUD (menu, level label, ink bar with star ticks, restart, mute), win and fail overlays, toasts for level tips.
- Rendering: nebula background, twinkling stars, saucer nozzles, glowing lime liquid, cup with alien face and antennae that changes mood with fill, magenta ink line.
- Saved progress in localStorage under `moonjuice.v1` (unlocked level, stars, mute).
- WebAudio sound effects with a mute toggle and the silent-track iOS workaround.
- 15 hand-built levels (`HAND`) plus a seeded procedural generator (`genLevel`) for levels past 15, labeled "Deep N".
- Two platform kinds: `rock` (grippy) and `ice` (frictionless for cup and liquid, grippy for ink).
- Test hooks on `window.MJ`: `simStroke(level, stroke, seed)` runs a level synchronously and returns the outcome. `searchLevel(level, N)` tries random strokes. A level sims in well under 1 s.

## Physics settings that matter

Tuned settings and the failure each one prevents:

- Physics substep is 1000/120 ms. Matter scales kinetic friction by timeScale³, so friction is weak at this step. Raising the step to 1000/60 made results worse, not better.
- The ink body is a compound of rectangles only (segment length + 0.7 × thickness). Circles at the joints produced violent spinning.
- Densities: cup 0.004, ink 0.0025, liquid 0.0006. A heavier ink line shoves the cup. A heavier cup cannot be held by an ink stopper on ice.
- Pair override (`Matter.Pair.update`): ink touching rock, ice, or a pin gets friction 1 and frictionStatic 3. The override excludes the cup. Grip between ink and the cup knocks cups over.
- Pins are small static rectangles (27 × 18), not circles. Ink slides off round pins.
- Speed cap of 12 per base step and spin cap of 0.12 rad per base step (`capSpeeds`).
- Drawing clearance: `Query.ray` width is ink thickness + 4. Strokes drawn flush against a body cause penetration explosions.
- `window.MJ_NOCAP = true` disables the caps for debugging.

## Level design rules learned

- Ramps must rest on two fixed supports (pins, ledge corners, or pillar tops). A ramp resting on the cup rim pushes the cup off its spot.
- The low support sits just outside the cup's rim so the ramp end overhangs the cup opening.
- Ramps steeper than about 45° slide even with boosted grip. Pin heights should give 25–35°.
- Liquid behaves like coarse sand. It piles on flat ledges and needs about 20° of slope to run.
- Ice levels: a small closed blob (about 30 × 24) drawn on the slope stops the cup. Each nozzle must sit above the spot where the cup actually comes to rest. Check this with the `cup` field returned by `simStroke`.

## Level status (current physics)

Pass means a win on all 3 seeds, plus a loss with no stroke. Reference strokes are in `tools/verified.py`.

| Level | Status | Notes |
|---|---|---|
| 1 | Pass | Second pin added at (232, 500). |
| 2 | Pass | Ice stopper blob at x = 190. |
| 3 | Fail | Ledge-spill ramp to a pin at (245, 500) stays dry. Needs a sloped ledge or a different ramp. |
| 4 | Pass | Pin moved to (330, 380). Ramp from the pin over the pillar top. |
| 5 | Fail | Wins with no stroke. The second saucer sits over the cup. Planned redesign: funnel with two pins. |
| 6 | Close | Stopper works. Cup rests near x = 200 but the saucer is at 125. |
| 7 | Untested | Needs a pin beside the raised cup platform. |
| 8 | Fail | Two-pin ramp at about 32° only reaches 0–9 of 16. |
| 9 | Untested | |
| 10 | Untested | Funnel level. Needs two pins. |
| 11 | Fail | Cup slides off the left edge past the stopper. |
| 12 | Fail | Wins with no stroke. |
| 13 | Fail | Reference stroke blocked by a pin. Without a stroke the cup fills to 16 of 17, so this level is nearly free. |
| 14 | Untested | Funnel level. Needs two pins. |
| 15 | Pass | Ice stopper blob at x = 230. |

The procedural generator copies the hand-built patterns (`peg`, `ice`, `ledge`, `twin`). Its templates have not been rechecked under the current physics.

## Tools

Run these from the package root.

- `python3 game/build.py` — rebuild `index.html` after any edit to `src.html`.
- `python3 tools/verified.py` — re-verify the passing levels.
- `python3 tools/sim.py nodraw` — check every level with no stroke.
- `python3 tools/sim.py search 60 3 5 8` — random-stroke search on the listed levels.
- `tools/batch.py` — `go([(level, overrides, [strokes])])` patches `MJ.HAND` at runtime and tests strokes. Overrides are not saved to `src.html`. Copy accepted changes into `src.html` by hand. `thru(p, q, x0, x1)` builds a straight stroke through two points. `blob(slab, x)` in `sols.py` builds an ice stopper.
- `python3 tools/grid.py 1 2 3` — start-screen contact sheet saved to `/tmp/grid.png`.
- `tools/seq.py` — real-time stroke playback screenshots, saved to `seqN.png`.
- `tools/setp.py CUP INK FS` — rewrites cup density, ink density, and the ink grip multiplier in `src.html`.
- `tools/run_all.py` and `tools/t.py` hold the original stroke set from the first build. Most of those strokes are stale.

## Remaining work

1. Retune levels 3 and 5–14 to pass, following the design rules above. Record each reference stroke in `tools/verified.py`.
2. Add a check that the no-stroke run loses on every level.
3. Revalidate the `genLevel` templates, or limit generation to verified templates.
4. Consider raising fill targets above 0.5. Winning runs currently hold about 38 particles against targets of 14–17.
5. Strip the test hooks and the `MJ_NOCAP` flag before shipping, or leave them inert.
6. Build the icon set: SVG, 32 px PNG, 192 px PNG, 180 px apple-touch, and multi-size ICO. `src.html` already links `favicon.svg` and `apple-touch-icon.png`.
