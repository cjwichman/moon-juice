# Inlines matter.js into src.html and writes index.html (the deployable single file).
import os
here = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(here, 'src.html')).read()
m = open(os.path.join(here, '..', 'vendor', 'matter.min.js')).read()
open(os.path.join(here, 'index.html'), 'w').write(src.replace('/*__MATTER__*/', m))
