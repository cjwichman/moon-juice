const MJ=require('./core.js');const lv=require('./levels.js')[+process.argv[2]-1];
const g=MJ.create(lv);let s=lv.sol,pts=[s[0]];
for(let i=1;i<s.length;i++){const a=s[i-1],b=s[i];const n=Math.max(1,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/8));for(let k=1;k<=n;k++){const p={x:a.x+(b.x-a.x)*k/n,y:a.y+(b.y-a.y)*k/n};if(MJ.segmentClear(g,pts[pts.length-1],p))pts.push(p);}}
MJ.addLine(g,pts);
for(let i=0;i<=480;i++){MJ.step(g);if(i%40==0&&g.line)console.log(i,g.line.position.x.toFixed(0),g.line.position.y.toFixed(0),(g.line.angle*57.3).toFixed(1),'cup',g.cup.position.x.toFixed(0),(g.cup.angle*57.3).toFixed(1),'n',MJ.cupCount(g.cup,g.particles));}
