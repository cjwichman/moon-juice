const MJ = require('./core.js');
const levels = require('./levels.js');
function run(lv, stroke, seed){
  let s=seed||1; Math.random=()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};
  const g = MJ.create(lv);
  // densify stroke to ~8px steps and validate
  let pts=[stroke[0]], blocked=false;
  for(let i=1;i<stroke.length;i++){const a=stroke[i-1],b=stroke[i];const L=Math.hypot(b.x-a.x,b.y-a.y);const n=Math.max(1,Math.round(L/8));
    for(let k=1;k<=n;k++){const p={x:a.x+(b.x-a.x)*k/n,y:a.y+(b.y-a.y)*k/n};if(!MJ.segmentClear(g,pts[pts.length-1],p)){blocked=true;continue;}pts.push(p);}}
  const ink=MJ.strokeLength(pts);
  MJ.addLine(g,pts);
  let r=null; for(let i=0;i<4000 && !r;i++){const e=MJ.step(g); if(e==='won'||e==='lost') r=e;}
  return {r, n:MJ.cupCount(g.cup,g.particles), target:g.target, ink:Math.round(ink), max:lv.ink, blocked, cupA:(g.cup.angle*57.3).toFixed(0), cupX:g.cup.position.x.toFixed(0)};
}
const only = process.argv[2]?+process.argv[2]:null;
levels.forEach((lv,i)=>{ if(only!==null && only!==i+1) return;
  const base = run(lv,[{x:380,y:20},{x:386,y:20}],1);
  if(!lv.sol){console.log('L'+(i+1)+' nodraw:'+base.r+'/'+base.n);return;} const sols = [1,2,3].map(sd=>run(lv,lv.sol,sd));
  console.log(`L${i+1} ${lv.name.padEnd(16)} nodraw:${base.r}/${base.n}  sol:`+sols.map(o=>`${o.r}/${o.n}`).join(' ')+` tgt ${lv.target} ink ${sols[0].ink}/${lv.ink}${sols[0].blocked?' BLOCKED':''} cupA ${sols[0].cupA}`);
});
