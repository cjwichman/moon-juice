/* Moon Juice physics core: world construction, ink lines, liquid, cup scoring. */
var MJ = (function () {
  var M = (typeof Matter !== 'undefined') ? Matter : require('../vendor/matter.js');
  var Engine = M.Engine, Bodies = M.Bodies, Body = M.Body, Composite = M.Composite, Query = M.Query;

  var W = 400, H = 700;
  var PR = 5;            // liquid particle radius (physics)
  var INK_T = 9;         // ink line thickness
  var CUP = { wb: 60, wt: 82, h: 82, t: 7 }; // inner bottom width, inner top width, height, wall thickness
  var STEP = 1000 / 120; // physics substep (ms)
  var EMIT_EVERY = 5;    // substeps between particles
  var SETTLE = 300;      // substeps after the last particle before judging (2.5 s)

  function deg(a) { return a * Math.PI / 180; }

  function makeCup(x, yBottom) {
    var t = CUP.t, h = CUP.h;
    var dx = (CUP.wt - CUP.wb) / 2;
    var lean = Math.atan2(dx, h);
    var wallLen = Math.sqrt(h * h + dx * dx);
    var opts = { friction: 0.01, frictionStatic: 0.1, density: 0.004, restitution: 0 };
    var base = Bodies.rectangle(x, yBottom - t / 2, CUP.wb + 2 * t, t, opts);
    var lx = x - CUP.wb / 2 - dx / 2 - t / 2, rx = x + CUP.wb / 2 + dx / 2 + t / 2;
    var wy = yBottom - t - h / 2 + t / 2;
    var left = Bodies.rectangle(lx, wy, t, wallLen, Object.assign({ angle: -lean }, opts));
    var right = Bodies.rectangle(rx, wy, t, wallLen, Object.assign({ angle: lean }, opts));
    var cup = Body.create({ parts: [base, left, right], friction: 0.01, frictionStatic: 0.1, restitution: 0, frictionAir: 0, label: 'cup' });
    // Offset from the compound centroid to the inner bottom-centre point, in the cup frame.
    cup.mjBottom = { x: x - cup.position.x, y: (yBottom - t) - cup.position.y };
    return cup;
  }

  // Liquid count inside the cup interior, measured in the cup's own frame.
  function cupCount(cup, particles) {
    var c = Math.cos(-cup.angle), s = Math.sin(-cup.angle), n = 0;
    var hb = CUP.wb / 2, ht = CUP.wt / 2;
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i].position;
      var dx = p.x - cup.position.x, dy = p.y - cup.position.y;
      var lx = dx * c - dy * s - cup.mjBottom.x;
      var ly = dx * s + dy * c - cup.mjBottom.y; // negative = above inner bottom
      if (ly > 2 || ly < -CUP.h - 4) continue;
      var half = hb + (ht - hb) * Math.min(1, -ly / CUP.h);
      if (Math.abs(lx) <= half + 1) n++;
    }
    return n;
  }

  // Height of the fill line above the inner bottom for a target particle count.
  function fillHeight(target) {
    var area = target * 82;  // calibrated settled area per particle (px^2)
    var lo = 0, hi = CUP.h;
    for (var k = 0; k < 30; k++) {
      var m = (lo + hi) / 2;
      var a = m * (CUP.wb + (CUP.wb + (CUP.wt - CUP.wb) * m / CUP.h)) / 2;
      if (a < area) lo = m; else hi = m;
    }
    return lo;
  }

  function create(level) {
    var engine = Engine.create({ positionIterations: 10, velocityIterations: 8 });
    engine.gravity.y = 1;
    var statics = level.blocks.map(function (b) {
      return Bodies.rectangle(b[0], b[1], b[2], b[3], { isStatic: true, angle: deg(b[4] || 0), friction: 1, label: 'block' });
    });
    var cup = makeCup(level.cup.x, level.cup.y);
    if (level.cup.a) Body.rotate(cup, deg(level.cup.a), { x: level.cup.x, y: level.cup.y });
    Composite.add(engine.world, statics.concat([cup]));
    var noz = level.nozzle;
    var a = deg(noz.a);
    return {
      level: level, engine: engine, statics: statics, cup: cup, line: null, linePts: null,
      particles: [], emitted: 0, tick: 0, doneTick: -1, state: 'draw',
      outlet: { x: noz.x + Math.cos(a) * 20, y: noz.y + Math.sin(a) * 20 },
      dir: { x: Math.cos(a), y: Math.sin(a) },
      target: level.target, water: level.water || 110
    };
  }

  // Validate that a new stroke segment does not pass through blocks, the cup, or the outlet zone.
  function segmentClear(g, p0, p1) {
    if (p1.x < 4 || p1.x > W - 4 || p1.y < 4 || p1.y > H - 4) return false;
    var hits = Query.ray(g.statics.concat([g.cup]), p0, p1, INK_T + 3);
    if (hits.length) return false;
    var ox = p1.x - g.outlet.x, oy = p1.y - g.outlet.y;
    return ox * ox + oy * oy > 26 * 26;
  }

  function strokeLength(pts) {
    var L = 0;
    for (var i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    return L;
  }

  function addLine(g, pts) {
    if (pts.length < 2) {
      pts = [pts[0], { x: pts[0].x + 0.5, y: pts[0].y }];
    }
    var opts = { density: 0.0025, friction: 1, frictionStatic: 3 };
    var parts = [];
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      var L = Math.hypot(b.x - a.x, b.y - a.y);
      parts.push(Bodies.rectangle((a.x + b.x) / 2, (a.y + b.y) / 2, L + INK_T * 0.7, INK_T,
        Object.assign({ angle: Math.atan2(b.y - a.y, b.x - a.x) }, opts)));
    }
    var body = parts.length === 1 ? parts[0] : Body.create({ parts: parts, friction: 1, frictionStatic: 3, label: 'ink' });
    body.label = 'ink';
    var cx = body.position.x, cy = body.position.y;
    g.line = body;
    g.linePts = pts.map(function (p) { return { x: p.x - cx, y: p.y - cy }; });
    Composite.add(g.engine.world, body);
    g.state = 'pour';
  }

  function emit(g) {
    var jitter = (Math.random() - 0.5) * 0.6;
    var sp = (g.level.nozzle.s || 2.2);
    var p = Bodies.circle(g.outlet.x + jitter * 4, g.outlet.y, PR, {
      friction: 0.02, frictionStatic: 0, frictionAir: 0.012, restitution: 0, density: 0.0012, slop: 0.02, label: 'drop'
    });
    Body.setVelocity(p, { x: g.dir.x * sp + jitter * 0.3, y: g.dir.y * sp });
    g.particles.push(p);
    Composite.add(g.engine.world, p);
    g.emitted++;
    return p;
  }

  // One physics substep. Returns an event string or null.
  function step(g) {
    var ev = null;
    if (g.state === 'pour' || g.state === 'settle') {
      if (g.state === 'pour' && g.tick % EMIT_EVERY === 0) {
        emit(g); ev = 'drop';
        if (g.emitted >= g.water) { g.state = 'settle'; g.doneTick = g.tick; }
      }
      g.tick++;
    }
    if (g.state !== 'draw') Engine.update(g.engine, STEP);
    // Remove escaped particles.
    for (var i = g.particles.length - 1; i >= 0; i--) {
      var p = g.particles[i];
      if (p.position.y > H + 60 || p.position.x < -80 || p.position.x > W + 80 || isNaN(p.position.x)) {
        Composite.remove(g.engine.world, p); g.particles.splice(i, 1);
      }
    }
    if (g.line && (g.line.position.y > H + 300 || isNaN(g.line.position.x))) {
      Composite.remove(g.engine.world, g.line); g.line = null;
    }
    if (g.state === 'pour' || g.state === 'settle') {
      var cp = g.cup.position;
      if (cp.y > H + 40 || isNaN(cp.x) || Math.abs(g.cup.angle) > deg(100)) { g.state = 'lost'; return 'lost'; }
      if (g.state === 'settle' && g.tick - g.doneTick > SETTLE) {
        g.state = cupCount(g.cup, g.particles) >= g.target ? 'won' : 'lost';
        return g.state;
      }
    }
    return ev;
  }

  return {
    W: W, H: H, PR: PR, INK_T: INK_T, CUP: CUP, STEP: STEP,
    create: create, addLine: addLine, step: step, cupCount: cupCount, fillHeight: fillHeight,
    segmentClear: segmentClear, strokeLength: strokeLength, Matter: M
  };
})();
if (typeof module !== 'undefined') module.exports = MJ;
