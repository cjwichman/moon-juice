const MJ=require('./core.js');const lv=require('./levels.js')[+process.argv[2]-1];
const g=MJ.create(lv);MJ.addLine(g,[{x:385,y:20},{x:390,y:20}]);
for(let i=0;i<=600;i++){MJ.step(g);if(i%60==0)console.log(i,'cup',g.cup.position.x.toFixed(1),g.cup.position.y.toFixed(1),(g.cup.angle*57.3).toFixed(1),'v',g.cup.velocity.x.toFixed(3),g.cup.velocity.y.toFixed(3));}
