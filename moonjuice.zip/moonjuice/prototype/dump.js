const MJ = require('./core.js');
const levels = require('./levels.js');
const [,,li,mode,tsec]=process.argv; const lv=levels[+li-1];
const g=MJ.create(lv);
let stroke = mode==='sol'?lv.sol:[{x:380,y:20},{x:386,y:20}];
let pts=[stroke[0]];
for(let i=1;i<stroke.length;i++){const a=stroke[i-1],b=stroke[i];const L=Math.hypot(b.x-a.x,b.y-a.y);const n=Math.max(1,Math.round(L/8));
 for(let k=1;k<=n;k++){const p={x:a.x+(b.x-a.x)*k/n,y:a.y+(b.y-a.y)*k/n};if(!MJ.segmentClear(g,pts[pts.length-1],p)){console.log('blocked at',p.x.toFixed(0),p.y.toFixed(0));continue;}pts.push(p);}}
MJ.addLine(g,pts);
const T=(+tsec||8)*120; let r; for(let i=0;i<T;i++){r=MJ.step(g)||r; if(r==='won'||r==='lost'){console.log('result',r,'at',i);break;}}
const C=50,R=44,grid=[...Array(R)].map(()=>Array(C).fill(' '));
const put=(x,y,ch)=>{const c=Math.floor(x/400*C),r=Math.floor(y/700*R);if(r>=0&&r<R&&c>=0&&c<C)grid[r][c]=ch;};
const Q=MJ.Matter.Query;
for(let r=0;r<R;r++)for(let c=0;c<C;c++){const p={x:(c+.5)*400/C,y:(r+.5)*700/R};
 if(Q.point(g.statics,p).length)grid[r][c]='#'; else if(Q.point([g.cup],p).length)grid[r][c]='U'; else if(g.line&&Q.point([g.line],p).length)grid[r][c]='=';}
g.particles.forEach(p=>put(p.position.x,p.position.y,'o')); put(g.outlet.x,g.outlet.y,'V');
console.log(grid.map(r=>'|'+r.join('')+'|').join('\n')); console.log('count',MJ.cupCount(g.cup,g.particles),'cup',g.cup.position.x.toFixed(0),g.cup.position.y.toFixed(0),(g.cup.angle*57.3).toFixed(0));
