const MJ=require('./core.js');const levels=require('./levels.js');
function rng(seed){let s=seed;return()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};}
function densify(g,stroke){let pts=[stroke[0]];if(!MJ.segmentClear(g,pts[0],pts[0]))return null;
 for(let i=1;i<stroke.length;i++){const a=stroke[i-1],b=stroke[i];const n=Math.max(1,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/8));
  for(let k=1;k<=n;k++){const p={x:a.x+(b.x-a.x)*k/n,y:a.y+(b.y-a.y)*k/n};if(!MJ.segmentClear(g,pts[pts.length-1],p))return null;pts.push(p);}}return pts;}
function sim(lv,stroke,seed){Math.random=rng(seed);const g=MJ.create(lv);const pts=densify(g,stroke);if(!pts)return null;
 const ink=MJ.strokeLength(pts);if(ink>lv.ink)return null;MJ.addLine(g,pts);
 for(let i=0;i<5000;i++){const e=MJ.step(g);if(e==='won')return{win:1,n:MJ.cupCount(g.cup,g.particles),ink};if(e==='lost')return{win:0,n:MJ.cupCount(g.cup,g.particles),ink};}return{win:0,n:-1,ink};}
const li=+process.argv[2], N=+process.argv[3]||150; const lv=levels[li-1];
const R=rng(99); const box=lv.region||[10,60,390,690];
let tried=0,wins=0,best=[];
const base=[1,2].map(s=>sim(lv,[{x:385,y:20},{x:390,y:20}],s));
while(tried<N){const np=2+Math.floor(R()*2);const st=[];for(let k=0;k<np;k++)st.push({x:Math.round(box[0]+R()*(box[2]-box[0])),y:Math.round(box[1]+R()*(box[3]-box[1]))});
 const r=sim(lv,st,7);if(!r)continue;tried++;if(r.win){const r2=sim(lv,st,8),r3=sim(lv,st,9);const w=1+r2.win+r3.win;wins++;best.push({w,st,ink:Math.round(r.ink),n:r.n});}}
best.sort((a,b)=>b.w-a.w||a.ink-b.ink);
console.log(`L${li} ${lv.name}: nodraw ${base.map(b=>b.win+'/'+b.n)} | random wins ${wins}/${tried}`);
best.slice(0,4).forEach(b=>console.log('  robust',b.w+'/3','ink',b.ink,'n',b.n,JSON.stringify(b.st)));
